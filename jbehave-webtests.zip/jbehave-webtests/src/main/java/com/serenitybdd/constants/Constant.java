package com.serenitybdd.constants;

public class Constant {

    public static final String user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36";
    public static final String client_Id="tenant001";
    public static final String client_Secret="67yl7Jyc4ZmP446Z442B67Gv5ZOH55an7ZuH35bur5vqoLLvj5jwqqiZ4r21";
    public static final String Store_id="02694d81-089e-11e7-b9bd-996dc218f0e4";
    public static final String Site_id="96419e50-0c71-11e7-8592-dfdc84ca8c1e";
    public static final String hostname="172.26.158.201";
    public static final Integer port=17050;
    public static final String basePath="http://"+hostname+":"+port;
    public static final String loginURL=basePath+"/api/v1/login";
    public static final String signUpURL=basePath+"/api/v1/customers";


}
