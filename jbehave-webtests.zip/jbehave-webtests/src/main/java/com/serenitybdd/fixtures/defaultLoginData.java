package com.serenitybdd.fixtures;

public class defaultLoginData {

}
