package com.serenitybdd.core;

import ch.qos.logback.core.ContextBase;

public class StoryContext extends ContextBase {
}
