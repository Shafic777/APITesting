package com.serenitybdd.core;

import ch.qos.logback.core.ContextBase;

public class ScenarioContext  extends ContextBase {

}
