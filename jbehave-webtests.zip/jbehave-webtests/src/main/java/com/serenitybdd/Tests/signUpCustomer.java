package com.serenitybdd.Tests;

import net.serenitybdd.jbehave.SerenityStory;

/**
 * Created by Shafic on 02/10/17.
 */

public class signUpCustomer extends SerenityStory {

}
